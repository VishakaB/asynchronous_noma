Tsym=1.25e-6;
Fdmax=40;
Ps=1;
SampleTime=3e-6;
SampleTime2=3e-6;
