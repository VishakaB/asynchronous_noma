function y=fr(x)
y=norm(x,'fro');
y=y*y;